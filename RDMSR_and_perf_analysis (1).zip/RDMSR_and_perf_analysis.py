
import matplotlib.pyplot as plt
import numpy as np

# Data
sampling_rates = [0.1, 1, 10, 100, 1000]
rdmsr_values = [99.99, 99.92, 99.34, 95.34, 88.07]
perf_values = [99.99, 99.98, 99.88, 99.01, 97.17]
barWidth = 0.3
r1 = range(len(sampling_rates))
r2 = [x + barWidth for x in r1]

# Plotting
plt.figure(figsize=(10,6))
plt.bar(r1, rdmsr_values, color='lightcoral', width=barWidth, edgecolor='white', label='RDMSR')
plt.bar(r2, perf_values, color='lightgreen', width=barWidth, edgecolor='white', label='perf')
plt.xlabel('Sampling Rate (Hz)', fontweight='bold')
plt.xticks([r + barWidth/2 for r in range(len(sampling_rates))], sampling_rates)
plt.ylabel('CPU Usage (%)')
plt.legend(loc='upper right')
plt.ylim(80, 100)
plt.savefig('/mnt/data/RDMSR_and_perf_values_no_title.pdf')
plt.show()
