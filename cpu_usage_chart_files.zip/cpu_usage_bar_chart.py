
import matplotlib.pyplot as plt

categories = ['Default', 'Classifier 1', 'Classifier 2', 'Classifier 3', 'Classifier 4']
values = [0.13, 1.97, 1.84, 0.55, 0.21]
difference_values = [0] + [values[i] - values[0] for i in range(1, len(values))]

plt.bar(categories, values, color='skyblue')
plt.bar(categories, difference_values, bottom=values[0], color='red', alpha=0.5)
plt.ylabel('CPU Usage (%)')

for i, v in enumerate(values):
    plt.text(i, v + 0.05, f"{v:.2f}%", ha='center')
for i, v in enumerate(difference_values[1:], start=1):
    if i == 4:
        plt.text(i, values[0] + v - 0.05, f"+{v:.2f}%", ha='center', color='white')
    else:
        plt.text(i, values[0] + v / 2, f"+{v:.2f}%", ha='center', color='white')

plt.xticks(rotation=45)
plt.savefig('CPU_Usage_Bar_Chart.pdf')
plt.show()
