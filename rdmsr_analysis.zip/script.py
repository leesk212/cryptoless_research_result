
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# 데이터 불러오기
data = pd.read_csv('rdmsr.csv', header=None)

# 텍스트 파일 데이터 불러오기
with open('rdmsr-test_on_miner.txt', 'r') as file:
    lines = file.readlines()
    
# 시간과 데이터 값을 저장할 리스트 생성
time_values = []
data_values = []

# 각 줄의 데이터를 분리하여 리스트에 추가
for line in lines:
    values = line.strip().split(',')
    if len(values) == 3:
        try:
            time_values.append(float(values[1]))
            data_values.append(int(values[2], 16))  # 16진수로 변환
        except:
            pass

# 시간 값을 누적시키기
cumulative_time_values = np.cumsum(time_values)

# CSV 데이터와 텍스트 데이터를 150초까지 확장
extended_csv_time = np.linspace(0, 150, len(data[0][data[0] <= 140]) + 100)
extended_csv_data = np.concatenate((data[1][data[0] <= 140].values, [data[1][data[0] <= 140].values[-1]] * 100))

# 텍스트 데이터의 마지막 값 찾기
last_text_data_value = data_values[-1]

# 누적 시간 값이 150초를 초과하지 않는 마지막 인덱스 찾기
last_valid_index = np.searchsorted(cumulative_time_values, 150)

# 텍스트 데이터 시간과 값 확장
extended_text_time = np.linspace(0, 150, last_valid_index + 100)
extended_text_data = np.concatenate((data_values[:last_valid_index], [last_text_data_value] * 100))

# 데이터를 시각화하며 제목 수정
plt.figure(figsize=(12,8))
plt.plot(extended_text_time, extended_text_data, marker='.', linestyle='-', label='The value of "rdmsr 0xc0000100"', color='red')
plt.plot(extended_csv_time, extended_csv_data, marker='o', linestyle='-', label='Context switches', markersize=3, color='green')
plt.xlabel('Time (s)')
plt.ylabel('Number of counter (n) [Log scale]')
plt.title('Comparison of RDMSR and Context Switches on running miner')
plt.yscale('log')
plt.legend(loc='lower right')
plt.grid(True)
plt.show()
